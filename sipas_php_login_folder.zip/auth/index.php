<?php
session_start();
if(isset($_SESSION['status']) && $_SESSION['status'] == "login"){
    header("location: ../jadwal_angkut/index.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SI-PAS - Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="../js/tailwind-config.js"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body class="bg-slate-50 text-slate-800 antialiased overflow-hidden h-screen flex flex-col">

    <div id="login-view" class="absolute inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-emerald-700 to-teal-900 p-4 transition-opacity duration-300">
        <div class="max-w-md w-full bg-white rounded-2xl shadow-2xl p-8 relative overflow-hidden">
            <div class="absolute top-0 right-0 -mr-8 -mt-8 w-32 h-32 rounded-full bg-emerald-50 opacity-50 pointer-events-none"></div>
            
            <div class="text-center mb-8 relative z-10">
                <div class="mx-auto w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-4 shadow-sm border border-emerald-200">
                    <i data-lucide="recycle" class="w-8 h-8"></i>
                </div>
                <h1 class="text-2xl font-bold text-slate-800">Masuk ke SI-PAS</h1>
                <p class="text-sm text-slate-500 mt-1">Sistem Pengelolaan Sampah Masyarakat</p>
            </div>

            <?php
            if(isset($_GET['pesan'])){
                if($_GET['pesan'] == "gagal"){
                    echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-xl mb-4 text-sm text-center font-medium'>Username atau Password salah!</div>";
                } else if($_GET['pesan'] == "logout"){
                    echo "<div class='bg-emerald-100 border border-emerald-400 text-emerald-700 px-4 py-3 rounded-xl mb-4 text-sm text-center font-medium'>Anda telah berhasil logout.</div>";
                }
            }
            ?>

            <form action="proses_login.php" method="POST" class="space-y-5 relative z-10">
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-1" for="username">Username</label>
                    <div class="relative">
                        <i data-lucide="user" class="absolute left-3 top-3 w-5 h-5 text-slate-400"></i>
                        <input type="text" id="username" name="username" class="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition" placeholder="Masukkan username" required>
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700 mb-1" for="password">Password</label>
                    <div class="relative">
                        <i data-lucide="lock" class="absolute left-3 top-3 w-5 h-5 text-slate-400"></i>
                        <input type="password" id="password" name="password" class="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition" placeholder="Masukkan password" required>
                    </div>
                </div>
                <div class="pt-2">
                    <button type="submit" class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 rounded-xl shadow-lg shadow-emerald-200 transition duration-200 flex justify-center items-center gap-2">
                        Masuk Aplikasi <i data-lucide="log-in" class="w-4 h-4"></i>
                    </button>
                </div>
            </form>
            
            <div class="mt-6 p-4 bg-amber-50 rounded-xl border border-amber-200 text-center">
                <p class="text-xs text-amber-700 font-medium">Database MySQL Aktif</p>
                <p class="text-xs text-amber-600">User: <b>warga</b> | Pass: <b>123456</b></p>
            </div>
        </div>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>